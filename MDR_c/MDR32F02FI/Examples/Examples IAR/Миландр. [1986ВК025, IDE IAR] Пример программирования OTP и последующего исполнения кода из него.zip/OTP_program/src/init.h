#ifndef TIMER_PWM_CPU_CLOCK_H
#define TIMER_PWM_CPU_CLOCK_H

void init_clock();

#endif //TIMER_PWM_CPU_CLOCK_H
