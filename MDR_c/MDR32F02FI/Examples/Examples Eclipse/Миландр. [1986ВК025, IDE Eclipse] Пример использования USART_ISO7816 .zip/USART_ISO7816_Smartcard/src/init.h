//
// Created by panukov.a on 17.03.2021.
//

#ifndef USE_INIT_H
#define USE_INIT_H

void init_clock();

void init_uart();

#endif //USE_INIT_H
